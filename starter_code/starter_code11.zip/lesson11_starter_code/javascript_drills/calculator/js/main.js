var num1;
var num2;
var total;

$('#plus').on('click', function(){
	set_nums();	
	add();
});

function add(){
	total = num1 + num2;

	$("#answer").html(total);
}

function set_nums(){
	num1 = parseInt($('#num1').val());
	num2 = parseInt($('#num2').val());
}
