// ----------------------------------------
// We do (refer to cheat sheet for syntax)
// ----------------------------------------

// 1. Declare a variable with the name "number1". Assign it the value 4.

// 2. Declare a variable with the name "number2". Assign it the value 10.

// 3. Write out an if / else if / else statement for the following conditions:

// if number1 is equal to number2
	// $('h1').html(number1 + " is equal to " + number2);

// else if number1 is less than number2
	// $('h1').html(number1 + " is less than " + number2);

// else
	// $('h1').html(number1 + " is greater than " + number2);
