// Make a bulldog object that takes in a name and has these properties:
// -name
// -legs
// -feed function that takes in food and alerts user of what they feed the dog


// make a form that allows a user to create a dog and name it
// make a form that allows a user to feed the dog


